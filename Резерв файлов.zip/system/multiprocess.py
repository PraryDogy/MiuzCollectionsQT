import os
import shutil
from datetime import datetime
from multiprocessing import Process, Queue
from pathlib import Path
from time import sleep

import sqlalchemy
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers.polling import PollingObserver as Observer

from cfg import Cfg, Static

from .database import ClmnNames, Dbase, Dirs, Thumbs
from .items import (CopyTaskItem, OneFileInfoItem, OnStartItem, ReadImgItem,
                    WatchDogItem)
from .lang import Lng
from .main_folder import Mf
from .shared_utils import ImgUtils, SharedUtils
from .tasks import Utils


class BaseProcessWorker:
    _registry = []

    def __init__(self, target: callable, args: tuple):
        super().__init__()
        self.proc = Process(target=target, args=(*args, ))
        self._queues: list[Queue] = [a for a in args if hasattr(a, 'put')]
        BaseProcessWorker._registry.append(self)

    def start(self):
        self.proc.start()

    def is_alive(self):
        return self.proc.is_alive()
    
    def terminate_join(self):
        """
        Корректно terminate с join
        Завершает все очереди Queue
        """
        self.proc.terminate()
        self.proc.join(timeout=0.2)

        for q in self._queues:
            q.close()
            q.cancel_join_thread()

        if self.proc.is_alive():
            self.proc.kill()

        if self in BaseProcessWorker._registry:
            BaseProcessWorker._registry.remove(self)

    @staticmethod
    def stop_all():
        for worker in BaseProcessWorker._registry.copy():
            worker: BaseProcessWorker
            worker.terminate_join()


class ProcessWorker(BaseProcessWorker):
    """
        Передает в BaseProcessWorker args + self.proc (Queue)
    """
    def __init__(self, target: callable, args: tuple):
        self.proc_q = Queue()
        super().__init__(target, (*args, self.proc_q))


class ReadImg:
    @staticmethod
    def start(src: str, desaturate: bool, q: Queue):
        img_array = ImgUtils.read_img(src)
        if desaturate:
            img_array = ImgUtils.desaturate_image(img_array, 0.2)
        q.put(ReadImgItem(src, img_array))


class OneFileInfo:

    @staticmethod
    def start(path: str, proc_q: Queue):
        """
        Возвращает в Queue либо dict либо str
        Если str, процесс окончен
        """
        try:
            info_item = OneFileInfo._gather_info(path)
            proc_q.put(info_item)

            resol = ImgUtils.get_img_res(path)
            if resol:
                info_item.res = resol
            proc_q.put(info_item)
        except Exception as e:
            Utils.print_error()

    @staticmethod
    def _gather_info(path: str) -> OneFileInfoItem:
        name = os.path.basename(path)
        _, type_ = os.path.splitext(name)
        stats = os.stat(path)
        size = SharedUtils.get_f_size(stats.st_size)
        date_time = datetime.fromtimestamp(stats.st_mtime)
        month = Lng.months_genitive_case[Cfg.lng][str(date_time.month)]
        mod = f"{date_time.day} {month} {date_time.year}"
        item = OneFileInfoItem(type_, size, mod, "")
        return item

    @staticmethod
    def lined_text(text: str, max_row = 50) -> str:
        if len(text) > max_row:
            return "\n".join(
                text[i:i + max_row]
                for i in range(0, len(text), max_row)
            )
        return text
    


class CopyTaskWorker(BaseProcessWorker):
    def __init__(self, target, args):
        self.proc_q = Queue()
        self.gui_q = Queue()
        super().__init__(target, (*args, self.proc_q, self.gui_q))


class CopyTask:
    @staticmethod
    def start(copy_item: CopyTaskItem, proc_q: Queue, gui_q: Queue):

        src_dst_urls = CopyTask.get_another_dir_urls(copy_item)
        copy_item.dst_urls = [dst for src, dst in src_dst_urls]

        total_size = 0
        for src, dest in src_dst_urls:
            total_size += os.path.getsize(src)

        copy_item.total_size = total_size // 1024
        copy_item.total_count = len(src_dst_urls)
        replace_all = False

        for count, (src, dest) in enumerate(src_dst_urls, start=1):

            if not replace_all and dest.exists() and src.name == dest.name:
                copy_item.msg = "need_replace"
                proc_q.put(copy_item)
                while True:
                    sleep(1)
                    if not gui_q.empty():
                        new_copy_item: CopyTaskItem = gui_q.get()
                        if new_copy_item.msg == "replace_one":
                            break
                        elif new_copy_item.msg == "replace_all":
                            replace_all = True
                            break

            copy_item.current_count = count
            copy_item.msg = ""
            try:
                CopyTask.copy_file_with_progress(proc_q, copy_item, src, dest)
            except Exception as e:
                print("CopyTask copy error", e)
                copy_item.msg = "error"
                proc_q.put(copy_item)
                return
            if copy_item.is_cut:
                os.remove(src)
                "удаляем файлы чтобы очистить директории"
        
        copy_item.msg = "finished"
        proc_q.put(copy_item)

    @staticmethod
    def get_another_dir_urls(copy_item: CopyTaskItem):
        src_dst_urls: list[tuple[Path, Path]] = []
        dst_dir = Path(copy_item.dst_dir)
        for url in copy_item.src_urls:
            url = Path(url)
            new_path = dst_dir.joinpath(url.name)
            src_dst_urls.append((url, new_path))
        return src_dst_urls
        
    @staticmethod
    def copy_file_with_progress(proc_q: Queue, copy_item: CopyTaskItem, src: Path, dest: Path):
        block = 4 * 1024 * 1024  # 4 MB
        with open(src, "rb") as fsrc, open(dest, "wb") as fdst:
            while True:
                buf = fsrc.read(block)
                if not buf:
                    break
                fdst.write(buf)
                copy_item.current_size += len(buf) // 1024
                proc_q.put(copy_item)
        try:
            shutil.copystat(src, dest, follow_symlinks=True)
        except OSError as e:
            # import traceback
            # print(traceback.format_exc())
            print("copy task - copy stat error", e)


class FilesRemover:
    @staticmethod
    def start(paths: list[str], q: Queue):
        deleted_files = []
        for path in paths:
            try:
                os.remove(path)
                deleted_files.append(path)
            except Exception as e:
                print("FilesRemover error:", e)
        q.put(deleted_files)
        

class _DeletedMfRemover:

    def start(engine: sqlalchemy.Engine, on_start_item: OnStartItem, q: Queue):
        """
        Логика такая:
        - Пользователь в настройках приложения удаляет Mf
        - Данные удаляются из БД, приложение перезапускается
        - RemoveMfCleaner вызывается при перезапуске приложения
        - Сравнивается список Mf в базе данных и список Mf в mf.json
        Если Mf нет в базе данных, но есть в mf.json, нужно удалить все данные
        по этой Mf:
        - изображения thumbs из hashdir в ApplicationSupport    
        - записи в базе данных
        Передает в Queue список удаленных Mf (список имен str)
        """
        conn = engine.connect()
        stmt = sqlalchemy.select(Thumbs.mf_alias).distinct()
        db_mf_list = conn.execute(stmt).scalars().all()
        json_mf_list = [i.mf_alias for i in on_start_item.mf_list]
        removed_mf_list: list[str] = [
            i
            for i in db_mf_list
            if i not in json_mf_list and i is not None
        ]

        if removed_mf_list:
            for i in removed_mf_list:
                rows = _DeletedMfRemover.get_rows(i, conn)
                _DeletedMfRemover.remove_images(rows)
                _DeletedMfRemover.remove_rows(rows, conn)
            _DeletedMfRemover.remove_dirs(conn)
        conn.close()
        q.put(removed_mf_list)
    
    @staticmethod
    def get_rows(mf_name: str, conn: sqlalchemy.Connection):
        q = sqlalchemy.select(Thumbs.id, Thumbs.rel_thumb_path).where(
            Thumbs.mf_alias == mf_name
        )
        return [
            (id_, Utils.get_abs_thumb_path(rel_thumb_path))
            for id_, rel_thumb_path in conn.execute(q).fetchall()
        ]

    @staticmethod
    def remove_images(rows: list):
        """
        rows: [(row id int, thumb path), ...]
        """
        for id_, image_path in rows:
            try:
                if os.path.exists(image_path):
                    os.remove(image_path)
                folder = os.path.dirname(image_path)
                if os.path.exists(folder) and not os.listdir(folder):
                    shutil.rmtree(folder)
            except Exception as e:
                print(f"new scaner utils, MfRemover, remove images error. ID: {id_}, Path: {image_path}, Error: {e}")
                continue

    @staticmethod
    def remove_rows(rows: list, conn: sqlalchemy.Connection):
        """
        rows: [(row id int, thumb path), ...]
        """
        ids = [id_ for id_, _ in rows]
        if ids:
            q = sqlalchemy.delete(Thumbs.table).where(Thumbs.id.in_(ids))
            conn.execute(q)
            conn.commit()

    @staticmethod
    def remove_dirs(conn: sqlalchemy.Connection):
        q = sqlalchemy.select(Dirs.mf_alias).distinct()
        db_brands = set(conn.execute(q).scalars())
        app_brands = set(i.mf_alias for i in Mf.mf_list)
        to_delete = db_brands - app_brands

        if to_delete:
            del_stmt = sqlalchemy.delete(Dirs.table).where(Dirs.mf_alias.in_(to_delete))
            conn.execute(del_stmt)
            conn.commit()


class _EmptyRecordsRemover:
    @staticmethod
    def start(engine: sqlalchemy.Engine, q: Queue):
        """
        При запуске приложения проверяет данные в базе данных и удаляет
        записи со значениями None
        Передает в очередь None
        """
        conn = engine.connect()
        stmt = (
            sqlalchemy.delete(Thumbs.table).where(
                sqlalchemy.or_(
                    Thumbs.rel_thumb_path == None,
                    Thumbs.rel_img_path == None
                )
            )
        )
        conn.execute(stmt)
        conn.commit()
        q.put(None)


class _EmptyHashdirRemover:
    @staticmethod
    def start(q: Queue):
        """
        При запуске приложения проверяет, есть ли пустые директории в thumbnails,
        удаляет лишние
        Передает в Queue список удаленных директорий
        """
        removed_dirs: list[str] = []
        for i in os.scandir(Static.external_hashdir):
            if os.path.isdir(i.path) and not os.listdir(i.path):
                try:
                    shutil.rmtree(i.path)
                    removed_dirs.append(i.path)
                except Exception as e:
                    print("new scaner, empty hashdir remover", e)
        if removed_dirs:
            q.put(removed_dirs)


class OnStartTask:
    @staticmethod
    def start(on_start_item: OnStartItem, q: Queue):
        engine = Dbase.create_engine()
        _DeletedMfRemover.start(engine, on_start_item, q)
        _EmptyRecordsRemover.start(engine, q)
        _EmptyHashdirRemover.start(q)



class _DirChangedHandler(FileSystemEventHandler):
    def __init__(self, callback):
        super().__init__()
        self.callback = callback

    def on_any_event(self, event: FileSystemEvent):
        if event.is_directory:
            self.callback(event)


class DirWatcher:
    @staticmethod
    def start(mf_list: list[Mf], q: Queue):
        observer = Observer()

        for mf in mf_list:
            callback = lambda e, mf=mf: q.put(
                WatchDogItem(mf=mf, event=e)
            )
            handler = _DirChangedHandler(callback)
            observer.schedule(handler, mf.mf_current_path, recursive=False)
        observer.start()

        try:
            while True:
                sleep(1)
        finally:
            observer.stop()
            observer.join()


class UpdateThumb:

    @staticmethod
    def start(mf: Mf, rel_img_path: str, q: Queue):
        try:
            img_array = UpdateThumb._start(mf, rel_img_path, q)
            q.put(img_array)
        except Exception as e:
            print("UpdateThumb task error", e)
            q.put(False)

    @staticmethod
    def _start(mf: Mf, rel_img_path: str, q: Queue):
        abs_img_path = Utils.get_abs_any_path(
            mf.mf_current_path, rel_img_path
        )
        abs_thumb_path = Utils.create_abs_thumb_path(
            rel_img_path, mf.mf_alias
        )
        rel_thumb_path = Utils.get_rel_thumb_path(
            abs_thumb_path
        )
        root = os.path.dirname(abs_thumb_path)
        stats = os.stat(abs_img_path)
        size = int(stats.st_size)
        mod = int(stats.st_mtime)
        img_array = ImgUtils.read_img(abs_img_path)
        img_array = ImgUtils.fit_to_thumb(img_array, Static.max_img_size)
        values = {
            ClmnNames.rel_item_path: rel_img_path,
            ClmnNames.rel_thumb_path: rel_thumb_path,
            ClmnNames.size: size,
            ClmnNames.birth: 0,
            ClmnNames.mod: mod,
            ClmnNames.resol: "none",
            ClmnNames.coll: "none",
            ClmnNames.fav: 0,
            ClmnNames.mf_alias: mf.mf_alias
            }
        
        os.remove(abs_thumb_path)
        if not os.listdir(root):
            shutil.rmtree(root)
        ImgUtils.write_thumb(abs_thumb_path, img_array)

        engine = Dbase.create_engine()
        conn = engine.connect()
        stmt = sqlalchemy.delete(Thumbs.table).where(
            Thumbs.mf_alias == mf.mf_alias,
            Thumbs.rel_img_path == rel_img_path
        )
        conn.execute(stmt)
        stmt = sqlalchemy.insert(Thumbs.table).values(values)
        conn.execute(stmt)
        conn.commit()
        conn.close()

        return img_array
