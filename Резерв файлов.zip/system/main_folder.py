import json
import os

from cfg import Static


class Mf:
    current_mf: "Mf" = None
    mf_list: list["Mf"] = []
    __slots__ = ["mf_alias", "mf_paths", "mf_stop_list", "mf_current_path",]

    def __init__(self, **kw):
        """
        mf_alias: str   
        mf_paths: list[str]    
        mf_stop_list: list[str]     
        mf_current_path: str    
        """
        super().__init__()
        self.mf_alias: str = kw["mf_alias"]
        self.mf_paths: list[str] = kw["mf_paths"]
        self.mf_stop_list: list[str] = kw["mf_stop_list"]
        self.mf_current_path: str = kw["mf_current_path"]

    def get_avaiable_mf_path(self):
        for i in self.mf_paths:
            if os.path.exists(i):
                return i
        return None

    def set_mf_current_path(self, path: str):
        self.mf_current_path = path
    
    def get_data(self):
        return {i: getattr(self, i) for i in self.__slots__}

    @classmethod
    def json_to_app(cls):
        try:
            with open(Static.external_mf, "r", encoding="utf-8") as file:
                data: list[dict] = json.load(file)
            for mf in data:
                if list(mf.keys()) != Mf.__slots__:
                    print("mf не сооветствует слотам", mf["mf_alias"])
                    continue
                elif not mf["mf_paths"]:
                    print("mf нет путей", mf["mf_alias"])
                    continue
                else:
                    cls.mf_list.append(Mf(**mf))
            if len(cls.mf_list) != 0:
                cls.current_mf = cls.mf_list[0]
                return True

        except Exception as e:
            # import traceback
            # print(traceback.format_exc())
            print("Mf json to app error", e)
            return None

    @classmethod
    def write_json_data(cls):
        with open(Static.external_mf, "w", encoding="utf-8") as file:
            data = [i.get_data() for i in cls.mf_list]
            json.dump(data, file, ensure_ascii=False, indent=4)
