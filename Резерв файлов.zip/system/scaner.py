import os
import shutil
from dataclasses import dataclass
from multiprocessing import Queue
from time import sleep

import sqlalchemy
from sqlalchemy.dialects.sqlite import insert as dialect_insert

from cfg import Static
from system.database import ClmnNames, Dbase, Dirs, Thumbs
from system.lang import Lng
from system.main_folder import Mf
from system.shared_utils import ImgUtils
from system.utils import Utils

from .items import ExtScanerItem, IntScanerItem, SingleDirScanerItem


@dataclass(slots=True)
class DirItem:
    """
    Параметры:
    - rel_path: относительный путь к подкаталогу относительно `Mf.curr_path`.
      Пример:
        - Mf.curr_path = /User/Downloads/parent/folder
        - подкаталог = /User/Downloads/parent/folder/subfolder
        - rel_path = /subfolder
    - mod: дата модификации каталога (os.stat.st_mtime)
    """
    abs_path: str
    rel_path: str
    mod: int


@dataclass(slots=True)
class ImgItem:
    """
    Параметры:
    - abs_img_path: полный путь до изображения
    - size: размер изображения в байтах
    - mod: os.stat.st_mtime
    - rel_thumb_path: путь до миниатюры /hashdir/thumb.jpg
    """
    abs_img_path: str
    size: int
    mod: int
    rel_thumb_path: str = ""


class AllDirLoader:
    @staticmethod
    def start(scaner_item: IntScanerItem):
        """
        - Собирает список всех вложенных директорий в каталоге `Mf.curr_path`
        - Собирает список всех директорий из базы данных, которые
          соответствуют `Mf.alias`
        """
        finder_dirs = AllDirLoader.get_finder_dirs(scaner_item)
        db_dirs = AllDirLoader.get_db_dirs(scaner_item)
        return (finder_dirs, db_dirs)

    @staticmethod
    def get_finder_dirs(scaner_item: IntScanerItem):
        """
        Собирает список директорий, которые:
        - есть в каталоге `Mf.curr_path`
        - не в стоп листе `Mf.stop_list`
        """
        # Отправляем текст в гуи что идет поиск в папке
        # gui_text: Имя папки: поиск в папке
        gui_text = (
            f"{scaner_item.mf.mf_alias}: "
            f"{Lng.search_in[scaner_item.lng_index].lower()}"
        )
        ext_scaner_item = ExtScanerItem(gui_text, False)
        scaner_item.q.put(ext_scaner_item)
        dirs: list[DirItem] = []
        stack = [scaner_item.mf.mf_current_path]
        while stack:
            try:
                scandir_iterator = os.scandir(stack.pop())
            except Exception as e:
                print("scaner > DirLoader error", e)
                continue
            for entry in scandir_iterator:
                try:
                    is_allowed = entry.name not in scaner_item.mf.mf_stop_list
                    stmt = (entry.is_dir() and is_allowed)
                except Exception as e:
                    print("scaner > DirLoader error", e)
                    continue
                if stmt:
                    # передаем с каждой итерацией в основной поток ScanerItem
                    # чтобы в основном потоке сбрасывался таймер таймаута
                    scaner_item.q.put(ext_scaner_item)
                    stack.append(entry.path)
                    rel_path = Utils.get_rel_any_path(
                        mf_path=scaner_item.mf.mf_current_path,
                        abs_img_path=entry.path
                    )
                    stats = entry.stat()
                    mod = int(stats.st_mtime)
                    dir_item = DirItem(entry.path, rel_path, mod)
                    dirs.append(dir_item)
        try:
            stats = os.stat(scaner_item.mf.mf_current_path)
            mod = int(stats.st_mtime)
            dir_item = DirItem(scaner_item.mf.mf_current_path, os.sep, mod)
            dirs.append(dir_item)
        except Exception as e:
            print("new scaner dirs loader finder dirs error add root dir", e)
        return dirs

    @staticmethod
    def get_db_dirs(scaner_item: IntScanerItem):
        """
        Возвращает список директорий из базы данных, которые:
        - соответствуют условию DIRS.c.brand == `Mf.alias`
        """
        conn = scaner_item.eng.connect()
        q = sqlalchemy.select(Dirs.rel_dir_path, Dirs.mod).where(
            Dirs.mf_alias == scaner_item.mf.mf_alias
        )
        dirs: list[DirItem] = []
        for rel_path, mod in conn.execute(q):
            rel_path: str
            abs_dir_path = os.path.join(
                os.sep,
                scaner_item.mf.mf_current_path.strip(os.sep),
                rel_path.strip(os.sep)
            )
            item = DirItem(abs_dir_path, rel_path, mod)
            dirs.append(item)
        conn.close()
        return dirs


class DirsCompator:
    @staticmethod
    def start(finder_dirs: list[DirItem], db_dirs: list[DirItem]):
        """
        Сравнивает директории из Finder и из базы данных:
        - Создает список удаленных директорий (нет в Finer, есть в БД)
        - Создает список новых директорий (есть в Finder, нет в БД)
        """
        dirs_to_remove = DirsCompator.get_dirs_to_remove(finder_dirs, db_dirs)
        dirs_to_scan = DirsCompator.get_dirs_to_scan(finder_dirs, db_dirs)
        return (dirs_to_remove, dirs_to_scan)

    @staticmethod
    def get_dirs_to_remove(finder_dirs: list[DirItem], db_dirs: list[DirItem]):
        """
        Собирает список `DirItem`:
        - которых больше нет в Finder, но есть в базе данных
        - которые нужно удалить из базы данных
        """
        rel_paths = [dir_item.rel_path for dir_item in finder_dirs]
        return [
            dir_item
            for dir_item in db_dirs
            if dir_item.rel_path not in rel_paths
        ]

    @staticmethod
    def get_dirs_to_scan(finder_dirs: list[DirItem], db_dirs: list[DirItem]):
        """
        Собирает список `DirItem`:
        - которые есть в Finder, но нет в базе данных
        - которые нужно добавить в базу данных
        """
        rel_paths = [
            (dir_item.rel_path, dir_item.mod)
            for dir_item in db_dirs
        ]
        return [
            dir_item
            for dir_item in finder_dirs
            if (dir_item.rel_path, dir_item.mod) not in rel_paths
        ]


class DbDirUpdater:
    @staticmethod
    def get_good_dirs(
        bad_del_images: list[ImgItem],
        bad_new_images: list[ImgItem],
        dirs_to_scan: list[DirItem]
    ):
        """
        Возвращает только те директории,
        где были успешно обработаны все изображения.
        """
        bad_images = {
            os.path.dirname(i.abs_img_path): i
            for i in bad_del_images + bad_new_images
        }

        return [
            i
            for i in dirs_to_scan
            if i.abs_path not in bad_images
        ]

    @staticmethod
    def start(scaner_item: IntScanerItem, dirs_to_scan: list[DirItem]):
        """
        Запускать только, когда:
        - добавлены и удалены изображения `ImgItem` из БД
        - добавлены и удалены изображения `ImgItem` из `hashdir`

        Работает с БД:
        - удаляет записи из `DIRS`, которые соответствуют `Mf.alias`
        - добавляет записи в `DIRS`, которые соответствуют `Mf.alias`
        - по сути это замена `sqlalchemy.update`
        """
        # удалить старые записи
        if not dirs_to_scan:
            return
        conn = scaner_item.eng.connect()
        rel_paths = [dir_item.rel_path for dir_item in dirs_to_scan]
        del_stmt = sqlalchemy.delete(Dirs.table).where(
            Dirs.rel_dir_path.in_(rel_paths),
            Dirs.mf_alias == scaner_item.mf.mf_alias
        )
        conn.execute(del_stmt)

        # вставить новые записи батчем
        values_list = [
            {
                ClmnNames.rel_item_path: dir_item.rel_path,
                ClmnNames.mod: dir_item.mod,
                ClmnNames.mf_alias: scaner_item.mf.mf_alias
            }
            for dir_item in dirs_to_scan
        ]
        if values_list:
            conn.execute(sqlalchemy.insert(Dirs.table), values_list)
        conn.commit()
        conn.close()
        return None


class ImgLoader:
    @staticmethod
    def start(scaner_item: IntScanerItem, dirs_to_scan: list[DirItem]):
        """
        - Обходит список `DirItem`:
            - Находит в Finder изображения и создает список `ImgItem`
            - Создает список `ImgItem` из записей БД с фильтрами:
                - Только из итерируемой директории
                - Если запись соответствует `Mf.alias`
        """
        finder_images = ImgLoader.get_finder_images(scaner_item, dirs_to_scan)
        db_images = ImgLoader.get_db_images(scaner_item, dirs_to_scan)
        return (finder_images, db_images)

    @staticmethod
    def get_finder_images(scaner_item: IntScanerItem, dir_list: list[DirItem]):
        """
        Собирает список `ImgItem` из указанных директорий:
        - fider_images список ImgItem
        """
        # передает в гуи текст
        # имя папки: поиск
        gui_text = (
            f"{scaner_item.mf.mf_alias}: "
            f"{Lng.search_in[scaner_item.lng_index].lower()}"
        )
        ext_scaner_item = ExtScanerItem(gui_text, False)
        scaner_item.q.put(ext_scaner_item)
        finder_images: list[ImgItem] = []
        for dir_item in dir_list:
            try:
                scandir_iterator = os.scandir(dir_item.abs_path)
            except Exception as e:
                print("scaner > ImgLoader error", e)
                continue
            for entry in scandir_iterator:
                if entry.path.endswith(ImgUtils.ext_all):
                    try:
                        stat = entry.stat()
                    except Exception as e:
                        print("scaner > ImgLoader error", e)
                        continue
                    # передаем в основной поток ScanerItem
                    # чтобы в основном потоке сбрасывался таймер таймаута
                    scaner_item.q.put(ext_scaner_item)
                    size = int(stat.st_size)
                    mod = int(stat.st_mtime)
                    if size == 0:
                        continue
                    img_item = ImgItem(entry.path, size, mod)
                    finder_images.append(img_item)
        return finder_images

    @staticmethod
    def get_db_images(scaner_item: IntScanerItem, dir_list: list[DirItem]):
        """
        Возвращает информацию об изображениях в БД из указанных директорий:
        - db_images список ImgItem
        """
        conn = scaner_item.eng.connect()
        db_images: list[ImgItem] = []
        for dir_item in dir_list:
            q = sqlalchemy.select(
                Thumbs.rel_thumb_path,
                Thumbs.rel_img_path,
                Thumbs.size,
                Thumbs.mod
                )
            q = q.where(Thumbs.mf_alias == scaner_item.mf.mf_alias)
            if dir_item.rel_path == os.sep:
                q = q.where(Thumbs.rel_img_path.ilike("/%"))
                q = q.where(Thumbs.rel_img_path.not_ilike(f"/%/%"))
            else:
                q = q.where(
                    Thumbs.rel_img_path.ilike(f"{dir_item.rel_path}/%")
                )
                q = q.where(
                    Thumbs.rel_img_path.not_ilike(f"{dir_item.rel_path}/%/%")
                )
            for rel_thumb_path, rel_path, size, mod in conn.execute(q):
                abs_img_path = Utils.get_abs_any_path(
                    mf_path=scaner_item.mf.mf_current_path,
                    rel_path=rel_path
                )
                img_item = ImgItem(
                    abs_img_path, size, mod, rel_thumb_path
                )
                db_images.append(img_item)
        conn.close()
        return db_images


class ImgCompator:
    @staticmethod
    def start(finder_images: list[ImgItem], db_images: list[ImgItem]):
        """
        Сравнивает данные об изображениях из Finder и базы данных.  
        Получить данные об изображениях необходимо из ImgLoader.    
        Параметры:      
        - finder_images список ImgItem
        - db_images список ImgItem

        Собирает списки `ImgItem`:
        - изображения, которых больше нет в Finder но есть в БД
        - изображения, которых нет в БД, но есть в Finder
        """
        finder_dict = {
            (i.abs_img_path, i.size, i.mod): i
            for i in finder_images
        }
        db_dict = {
            (i.abs_img_path, i.size, i.mod): i
            for i in db_images
        }
        removed_images = [
            img_item
            for data, img_item in db_dict.items()
            if data not in finder_dict
        ]
        new_images = [
            img_item
            for data, img_item in finder_dict.items()
            if data not in db_dict
        ]
        return removed_images, new_images


class HashdirImgUpdater:

    @staticmethod
    def run_del_images(scaner_item: IntScanerItem, del_images: list[ImgItem]):
        """
        Пытается удалить изображения из `hashdir` и пустые папки.   
        Возвращает список успешно удаленных изображений и
        список неудачно удаленных изображений.
        Обрати внимание:
        - Только в списке del_images есть параметр `ImgItem.rel_thumb_path`
        - Он был присвоен при загрузуке записей из БД
        - Необходим, чтоб сформировать полный путь до миниатюры и удалить ее
        """
        ext_scaner_item = ExtScanerItem("none", False)
        ok_del_images: list[ImgItem] = []
        bad_del_images: list[ImgItem] = []
        for img_item in del_images:
            scaner_item.total_count -= 1
            HashdirImgUpdater.q_put(scaner_item, ext_scaner_item)
            thumb_path = Utils.get_abs_thumb_path(img_item.rel_thumb_path)
            if os.path.exists(thumb_path):
                try:
                    os.remove(thumb_path)
                    folder = os.path.dirname(thumb_path)
                    if not os.listdir(folder):
                        shutil.rmtree(folder)
                    ok_del_images.append(img_item)
                except Exception as e:
                    print("scaner HashdirImgUpdater error", e)
                    bad_del_images.append(img_item)
                    continue
        return ok_del_images, bad_del_images

    @staticmethod
    def run_new_images(scaner_item: IntScanerItem, new_images: list[ImgItem]):
        """
        Пытается создать изображения в "hashdir".     
        Возвращает список успешно созданных изображений и
        список неудачно созданных изображений.
        """
        ext_scaner_item = ExtScanerItem("none", False)
        ok_new_images: list[ImgItem] = []
        bad_new_images: list[ImgItem] = []
        for img_item in new_images:
            scaner_item.total_count -= 1    
            HashdirImgUpdater.q_put(scaner_item, ext_scaner_item)
            img = ImgUtils.read_img(img_item.abs_img_path)
            img = ImgUtils.fit_to_thumb(img, Static.max_img_size)
            if img is not None:
                try:
                    rel_img_path = Utils.get_rel_any_path(
                        mf_path=scaner_item.mf.mf_current_path,
                        abs_img_path=img_item.abs_img_path
                    )
                    thumb_path = Utils.create_abs_thumb_path(
                        rel_img_path=rel_img_path,
                        mf_alias=scaner_item.mf.mf_alias
                    )
                    ImgUtils.write_thumb(thumb_path, img)
                    ok_new_images.append(img_item)
                except Exception as e:
                    print("scaner HashdirImgUpdater error", e)
                    bad_new_images.append(img_item)
                    continue
            else:
                bad_new_images.append(img_item)
        return ok_new_images, bad_new_images

    @staticmethod
    def q_put(scaner_item: IntScanerItem, ext_scaner_item: ExtScanerItem):
        text = (
            f"{scaner_item.mf.mf_alias}: "
            f"{Lng.updating[scaner_item.lng_index].lower()} "
            f"({scaner_item.total_count})"
        )
        ext_scaner_item.gui_text = text
        scaner_item.q.put(ext_scaner_item)


class DbImgUpdater:

    @staticmethod
    def remove_del_imgs(scaner_item: IntScanerItem, del_images: list[ImgItem]):
        """
        Удаляет из БД удаленные изображения.
        """
        conn = scaner_item.eng.connect()
        rel_thumb_paths = [i.rel_thumb_path for i in del_images]
        q = sqlalchemy.delete(Thumbs.table).where(
            Thumbs.rel_thumb_path.in_(rel_thumb_paths),
            Thumbs.mf_alias == scaner_item.mf.mf_alias
        )
        conn.execute(q)
        conn.commit()
        conn.close()
        ext_item = ExtScanerItem("", True)
        scaner_item.q.put(ext_item)

    @staticmethod
    def add_new_imgs(scaner_item: IntScanerItem, new_images: list[ImgItem]):
        """
        Добавляет записи из БД об успешно сохраненных изображениях.
        """
        conn = scaner_item.eng.connect()
        values_list = []
        for img_item in new_images:
            rel_img_path = Utils.get_rel_any_path(
                mf_path=scaner_item.mf.mf_current_path,
                abs_img_path=img_item.abs_img_path
            )
            abs_thumb_path = Utils.create_abs_thumb_path(
                rel_img_path=rel_img_path,
                mf_alias=scaner_item.mf.mf_alias
            )
            rel_thumb_path = Utils.get_rel_thumb_path(abs_thumb_path)
            values_list.append({
                ClmnNames.rel_item_path: rel_img_path,
                ClmnNames.rel_thumb_path: rel_thumb_path,
                ClmnNames.size: img_item.size,
                ClmnNames.birth: 0,
                ClmnNames.mod: img_item.mod,
                ClmnNames.resol: "none",
                ClmnNames.coll: "none",
                ClmnNames.fav: 0,
                ClmnNames.mf_alias: scaner_item.mf.mf_alias
            })
        stmt = dialect_insert(Thumbs.table).values(values_list)
        stmt = stmt.on_conflict_do_update(
            index_elements=[Thumbs.rel_thumb_path],
            set_={
                ClmnNames.rel_item_path: stmt.excluded[ClmnNames.rel_item_path],
                ClmnNames.size: stmt.excluded[ClmnNames.size],
                ClmnNames.birth: stmt.excluded[ClmnNames.birth],
                ClmnNames.mod: stmt.excluded[ClmnNames.mod],
                ClmnNames.resol: stmt.excluded[ClmnNames.resol],
                ClmnNames.coll: stmt.excluded[ClmnNames.coll],
                ClmnNames.fav: stmt.excluded[ClmnNames.fav],
                ClmnNames.mf_alias: stmt.excluded[ClmnNames.mf_alias]
            }
        )
        conn.execute(stmt)
        conn.commit()
        conn.close()


class NewDirsWorker:    
    @staticmethod
    def start(dirs_to_scan: list[DirItem], scaner_item: IntScanerItem):
        """
        Параметры: 
        - dirs_to_scan список DirItem
        - на основе этого списка добавляются и удаляются миниатюры в "hashdir"
        - обновляются базы данных THUMBS и DIRS
        """

        finder_images, db_images = ImgLoader.start(
            scaner_item=scaner_item,
            dirs_to_scan=dirs_to_scan
        )
        del_images, new_images = ImgCompator.start(
            finder_images=finder_images,
            db_images=db_images
        )
        # общий счет для отображения в GUI
        scaner_item.total_count = len(del_images) + len(new_images)
        # удаляем миниатюры
        ok_del_images, bad_del_images = HashdirImgUpdater.run_del_images(
            scaner_item=scaner_item,
            del_images=del_images
        )
        # обновляем БД об успешно удаленных миниатюрах
        DbImgUpdater.remove_del_imgs(
            scaner_item=scaner_item,
            del_images=ok_del_images
        )

        # создаем список неуспешно созданных миниатюр
        bad_new_images: list[ImgItem] = []
        # шаг про котором мы пишем минитюры и обновляем БД
        step = 10
        # делим новые миниатюры на списки по 10
        chunked_new_images = [
            new_images[i:i+step]
            for i in range(0, len(new_images), step)
        ]
        for new_images_chunk in chunked_new_images:
            # создаем миниатюры с шагом 10
            # получаем успешно и неуспешно созданные миниатюры
            ok_chunks, bad_chunks = HashdirImgUpdater.run_new_images(
                scaner_item=scaner_item,
                new_images=new_images_chunk
            )

            # обновляем БД об успешно созданных миниатюрах
            DbImgUpdater.add_new_imgs(
                scaner_item=scaner_item,
                new_images=ok_chunks
            )
            # обновляем список неуспешно созданных миниатюр
            bad_new_images.extend(bad_chunks)

        dirs_to_scan = DbDirUpdater.get_good_dirs(
            bad_del_images=bad_del_images,
            bad_new_images=bad_new_images,
            dirs_to_scan=dirs_to_scan
        )

        DbDirUpdater.start(
            scaner_item=scaner_item,
            dirs_to_scan=dirs_to_scan
        )

        return (del_images, new_images)
    



# ЭТОТ КЛАСС НУЖЕН ЕСЛИ САМА ПАПКА С ФОТКАМИ БЫЛА УДАЛЕНА

class RemovedDirsWorker:
    @staticmethod
    def start(dirs_to_del: list[DirItem], scaner_item: IntScanerItem):
        """
        Если директория с содержимым была удалена, она не попадет в new_dirs,
        так как ее как бы не существует
        """
        conn = scaner_item.eng.connect()
        for dir_item in dirs_to_del:
            RemovedDirsWorker.remove_thumbs(dir_item, scaner_item, conn)
            RemovedDirsWorker.remove_dir_entry(dir_item, scaner_item, conn)
        conn.commit()
        conn.close()

    @staticmethod
    def remove_thumbs(
        dir_item: DirItem,
        scaner_item: IntScanerItem,
        conn: sqlalchemy.Connection
    ):
        stmt = (
            sqlalchemy.select(Thumbs.rel_thumb_path)
            .where(Thumbs.rel_img_path.ilike(f"{dir_item.rel_path}/%"))
            .where(Thumbs.rel_img_path.not_ilike(f"{dir_item.rel_path}/%/%"))
            .where(Thumbs.mf_alias == scaner_item.mf.mf_alias)
        )
        for rel_thumb_path in conn.execute(stmt).scalars():
            try:
                os.remove(Utils.get_abs_thumb_path(rel_thumb_path))
            except Exception as e:
                print("DelDirsHandler, remove thumb:", e)

        del_stmt = (
            sqlalchemy.delete(Thumbs.table)
            .where(Thumbs.rel_img_path.ilike(f"{dir_item.rel_path}/%"))
            .where(Thumbs.rel_img_path.not_ilike(f"{dir_item.rel_path}/%/%"))
            .where(Thumbs.mf_alias == scaner_item.mf.mf_alias)
        )
        conn.execute(del_stmt)

    def remove_dir_entry(
            dir_item: DirItem,
            scaner_item: IntScanerItem,
            conn: sqlalchemy.Connection
        ):
        stmt = (
            sqlalchemy.delete(Dirs.table)
            .where(Dirs.rel_dir_path == dir_item.rel_path)
            .where(Dirs.mf_alias == scaner_item.mf.mf_alias)
        )
        conn.execute(stmt)


class AllDirScaner:
    @staticmethod
    def start(mf_list: list[Mf], lng_index: int, q: Queue):
        engine = Dbase.create_engine()
        # нельзя обращаться сразу к Mf так как это мультипроцесс
        for mf in mf_list:
            scaner_item = IntScanerItem(
                mf=mf,
                eng=engine,
                q=q,
                lng_index=lng_index
            )
            avaible_mf_path = scaner_item.mf.get_avaiable_mf_path()
            if avaible_mf_path:
                scaner_item.mf.set_mf_current_path(avaible_mf_path)
                try:
                    print("scaner started", scaner_item.mf.mf_alias)
                    AllDirScaner.single_mf_scan(scaner_item)
                    print("scaner finished", scaner_item.mf.mf_alias)
                except Exception as e:
                    import traceback
                    print(traceback.format_exc())
                    continue
            else:
                no_conn = Lng.no_connection[lng_index].lower()
                gui_text = (
                    f"{scaner_item.mf.mf_alias}: "
                    f"{no_conn}"
                )
                ext_scaner_item = ExtScanerItem(gui_text, False)
                scaner_item.q.put(ext_scaner_item)
                print(
                    "scaner no connection",
                    scaner_item.mf_real_name,
                    scaner_item.mf.mf_alias
                )
                sleep(3)
        engine.dispose()

    @staticmethod
    def single_mf_scan(scaner_item: IntScanerItem):
        # собираем Finder директории и директории из БД
        finder_dirs, db_dirs = AllDirLoader.start(scaner_item)
        if not finder_dirs:
            print(scaner_item.mf.mf_alias, "no finder dirs")
            return
        removed_dirs, new_dirs = DirsCompator.start(finder_dirs, db_dirs)
        if new_dirs:
            new_dirs.extend(removed_dirs)
            del_images, new_images = NewDirsWorker.start(new_dirs, scaner_item)
            if del_images or new_images:
                ext_scaner_item = ExtScanerItem(
                    gui_text="",
                    reload_gui=True
                )
                scaner_item.q.put(ext_scaner_item)
        # это нужно, когда удален целый каталог вместе с корневой папкой
        # типа не все фотки из папки "test" и папка "test" пуста,
        # а была удалена папка "test"
        # тогда это улетает в RemovedDirsWorker
        if removed_dirs:
            RemovedDirsWorker.start(removed_dirs, scaner_item)


class SingleDirScaner:

    @staticmethod
    def start(scaner_item: SingleDirScanerItem, lng_index: int, q: Queue):
        for mf, dirs_to_scan in scaner_item.data.items():
            print("single dir scaner started, mf:", mf.mf_alias)
            SingleDirScaner.single_mf_scan(
                mf=mf,
                dirs_to_scan=dirs_to_scan,
                lng_index=lng_index,
                q=q
            )
            print("single dir scaner finished, mf:", mf.mf_alias)

    @staticmethod
    def single_mf_scan(mf: Mf, dirs_to_scan: list[str], lng_index: int, q: Queue):
        """
        Сканирует заданне директории в пределах Mf на предмет новых или
        удаленных изображений.

        Параметры:
        - mf: сканируемая директория должна принадлежать определенному Mf
        - dirs_to_scan: директории, которые нужно просканировать
        """
        engine = Dbase.create_engine()
        scaner_item = IntScanerItem(
            mf=mf,
            eng=engine,
            q=q,
            lng_index=lng_index
        )
        avaiable_mf_path = scaner_item.mf.get_avaiable_mf_path()
        if avaiable_mf_path:
            scaner_item.mf.set_mf_current_path(avaiable_mf_path)
            dir_items: list[DirItem] = []
            for i in dirs_to_scan:
                try:
                    mod = int(os.stat(i).st_mtime)
                except Exception as e:
                    print("SingleDirScaner error", e)
                    continue
                item = DirItem(
                    abs_path=i,
                    rel_path=Utils.get_rel_any_path(mf.mf_current_path, i),
                    mod=mod
                )
                dir_items.append(item)
            if dir_items:
                del_img, new_img = NewDirsWorker.start(dir_items, scaner_item)
                if del_img or new_img:
                    ext_scaner_item = ExtScanerItem(
                        gui_text="",
                        reload_gui=True
                    )
                    scaner_item.q.put(ext_scaner_item)