from PyQt5.QtCore import Qt, pyqtSignal

from cfg import Dynamic, Cfg
from system.filters import Filters
from system.lang import Lng

from ._base_widgets import (SingleActionWindow, SmallBtn, UListSpacerItem,
                            UListWidgetItem, VListWidget)


class WinFilters(SingleActionWindow):
    closed_ = pyqtSignal()
    reload_thumbnails = pyqtSignal()
    ww = 400
    hh = 400

    def __init__(self):
        super().__init__()
        self.setWindowTitle(Lng.filters[Cfg.lng])
        self.setFixedSize(self.ww, self.hh)

        self.list_widget = VListWidget()
        self.list_widget.itemClicked.connect(self.item_cmd)
        self.central_layout.addWidget(self.list_widget)

        favs_item = UListWidgetItem(
            parent=self.list_widget,
            text=Lng.favorites[Cfg.lng]
        )
        favs_item.setFlags(
            favs_item.flags() | Qt.ItemFlag.ItemIsUserCheckable
        )
        favs_item.setCheckState(Qt.CheckState.Unchecked)
        self.list_widget.addItem(favs_item)
        if Dynamic.filter_favs:
            favs_item.setCheckState(Qt.CheckState.Checked)

        folder_item = UListWidgetItem(
            parent=self.list_widget,
            text=Lng.only_this_folder[Cfg.lng]
        )
        folder_item.setFlags(
            folder_item.flags() | Qt.ItemFlag.ItemIsUserCheckable
        )
        folder_item.setCheckState(Qt.CheckState.Unchecked)
        self.list_widget.addItem(folder_item)
        if Dynamic.filter_only_folder:
            folder_item.setCheckState(Qt.CheckState.Checked)

        self.list_widget.addItem(UListSpacerItem(parent=self.list_widget))

        for i in Filters.filter_list:
            item = UListWidgetItem(
                parent=self.list_widget,
                text=i
            )
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            self.list_widget.addItem(item)
            if i in Dynamic.filters_enabled:
                item.setCheckState(Qt.CheckState.Checked)

        self.list_widget.setCurrentRow(0)

        self.central_layout.setSpacing(10)
        marings = self.central_layout.contentsMargins()
        marings.setBottom(15)
        self.central_layout.setContentsMargins(marings)

        self.reset_btn = SmallBtn(Lng.reset[Cfg.lng])
        self.reset_btn.setFixedWidth(100)
        self.reset_btn.clicked.connect(self.reset_cmd)
        self.central_layout.addWidget(
            self.reset_btn,
            alignment=Qt.AlignmentFlag.AlignCenter
        )

    def item_cmd(self, item: UListWidgetItem):
        if item.text() == Lng.favorites[Cfg.lng]:
            if Dynamic.filter_favs:
                Dynamic.filter_favs = False
                item.setCheckState(Qt.CheckState.Unchecked)
            else:
                Dynamic.filter_favs = True
                item.setCheckState(Qt.CheckState.Checked)
        elif item.text() == Lng.only_this_folder[Cfg.lng]:
            if Dynamic.filter_only_folder:
                Dynamic.filter_only_folder = False
                item.setCheckState(Qt.CheckState.Unchecked)
            else:
                Dynamic.filter_only_folder = True
                item.setCheckState(Qt.CheckState.Checked)
        elif item.text() in Dynamic.filters_enabled:
            Dynamic.filters_enabled.remove(item.text())
            item.setCheckState(Qt.CheckState.Unchecked)
        else:
            Dynamic.filters_enabled.append(item.text())
            item.setCheckState(Qt.CheckState.Checked)
        self.reload_thumbnails.emit()

    def reset_cmd(self):
        items = [
            self.list_widget.item(i)
            for i in range(self.list_widget.count())
        ]
        # удаляем спейсер
        items.pop(2)
        for item in items:
            item.setCheckState(Qt.CheckState.Unchecked)
        Dynamic.filter_favs = False
        Dynamic.filter_only_folder = False
        Dynamic.filters_enabled.clear()
        self.reload_thumbnails.emit()
        self.deleteLater()

    def closeEvent(self, a0):
        self.closed_.emit()
        return super().closeEvent(a0)
    
    def deleteLater(self):
        self.closed_.emit()
        return super().deleteLater()
    
    def keyPressEvent(self, a0):
        if a0.key() == Qt.Key.Key_Escape:
            self.deleteLater()
        return super().keyPressEvent(a0)